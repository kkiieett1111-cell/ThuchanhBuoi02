﻿using System.ComponentModel.DataAnnotations;

namespace TvkietLab1.Models
{
    public class Student
    {
        public int Id { get; set; } //Mã sinh viên

        [Required(ErrorMessage = "Họ tên bắt buộc phải được nhập")]
        [StringLength(100, MinimumLength = 4, ErrorMessage = "Họ tên phải từ 4 đến 100 ký tự")]
        [Display(Name = "Họ tên")]
        public string? Name { get; set; } //Họ tên

        [Required(ErrorMessage = "Email bắt buộc phải được nhập")]
        [RegularExpression(@"^[A-Za-z0-9._%+-]+@gmail\.com$", ErrorMessage = "Email phải có đuôi @gmail.com")]
        [Display(Name = "Email")]
        public string? Email { get; set; } //Email

        [Required(ErrorMessage = "Mật khẩu bắt buộc phải được nhập")]
        [StringLength(100, MinimumLength = 8, ErrorMessage = "Mật khẩu phải từ 8 ký tự trở lên")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$", ErrorMessage = "Mật khẩu phải có chữ hoa, chữ thường, chữ số và ký tự đặc biệt")]
        [DataType(DataType.Password)]
        [Display(Name = "Mật khẩu")]
        public string? Password { get; set; }//Mật khẩu

        [Required(ErrorMessage = "Vui lòng chọn ngành học")]
        [Display(Name = "Ngành học")]
        public Branch? Branch { get; set; }//Ngành học

        [Required(ErrorMessage = "Vui lòng chọn giới tính")]
        [Display(Name = "Giới tính")]
        public Gender? Gender { get; set; }//Giới tính

        [Display(Name = "Hệ chính quy")]
        public bool IsRegular { get; set; }//Hệ: true-chính qui, phi cQ

        [Required(ErrorMessage = "Địa chỉ bắt buộc phải được nhập")]
        [DataType(DataType.MultilineText)]
        [Display(Name = "Địa chỉ")]
        public string? Address { get; set; }//Địa chỉ

        [Required(ErrorMessage = "Ngày sinh bắt buộc phải được nhập")]
        [DataType(DataType.Date)]
        [Range(typeof(DateTime), "1/1/1963", "12/31/2005", ErrorMessage = "Ngày sinh phải từ năm 1963 đến 2005")]
        [Display(Name = "Ngày sinh")]
        public DateTime DateOfBorth { get; set; }//Ngày sinh

        [Required(ErrorMessage = "Điểm số bắt buộc phải được nhập")]
        [Range(0.0, 10.0, ErrorMessage = "Điểm số phải nằm trong khoảng từ 0.0 đến 10.0")]
        [Display(Name = "Điểm số")]
        public double Score { get; set; }//Điểm số
    }
}