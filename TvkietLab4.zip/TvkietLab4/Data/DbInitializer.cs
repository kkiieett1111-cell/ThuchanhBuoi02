﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Linq;
using TvkietLab1.Data;
using TvkietLab1.Models;
using TvkLab3.Models;

namespace TvkietLab1.Data
{
    public class DbInitializer
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new SchoolContext(
                serviceProvider.GetRequiredService<DbContextOptions<SchoolContext>>()))
            {
                context.Database.EnsureCreated();

                if (context.Majors.Any())
                {
                    return; // DB đã có dữ liệu
                }

                var majors = new Major[]
                {
                    new Major{MajorName="IT"},
                    new Major{MajorName="Economics"},
                    new Major{MajorName="Mathematics"}
                };
                context.Majors.AddRange(majors);
                context.SaveChanges();

                var learners = new Learner[]
                {
                    new Learner{FirstMidName="Carson", LastName="Alexander", EnrollmentDate=DateTime.Parse("2005-09-01"), MajorID=1},
                    new Learner{FirstMidName="Meredith", LastName="Alonso", EnrollmentDate=DateTime.Parse("2002-09-01"), MajorID=2}
                };
                context.Learners.AddRange(learners);
                context.SaveChanges();

                var courses = new Course[]
                {
                    new Course{CourseID=1050, Title="Chemistry", Credits=3},
                    new Course{CourseID=4022, Title="Microeconomics", Credits=3},
                    new Course{CourseID=4041, Title="Macroeconomics", Credits=3}
                };
                context.Courses.AddRange(courses);
                context.SaveChanges();

                var enrollments = new Enrollment[]
                {
                    new Enrollment{LearnerID=1, CourseID=1050, Grade=5.5f},
                    new Enrollment{LearnerID=1, CourseID=4022, Grade=7.5f},
                    new Enrollment{LearnerID=2, CourseID=1050, Grade=3.5f},
                    new Enrollment{LearnerID=2, CourseID=4041, Grade=7.0f}
                };
                context.Enrollments.AddRange(enrollments);
                context.SaveChanges();
            }
        }
    }
}